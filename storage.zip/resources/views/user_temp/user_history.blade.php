@extends('user_temp.user-profile-template');

@section('user-content')
  <h1>User Profile History</h1>
@endsection
