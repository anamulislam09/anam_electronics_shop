@extends('user_temp.user-profile-template');

@section('user-content')
  <h1>User Dashboard</h1>
@endsection
