@extends('user_temp.layouts.template')

@section('main-content')
  <h1>Customers Service</h1>
@endsection
